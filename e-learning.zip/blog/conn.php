<?php 
  
      $conn=mysqli_connect("localhost","root","","myblog")or die("error connecting".mysqli_connect_error());

?>