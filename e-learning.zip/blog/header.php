<div class="wrap100">
    <div class="row wrap80">
        <div class="col col-sm-3 left">
            <ul class="navbar">
                <li><span>BLOG</span></li>
                <li><span>Home</span></li>
                <li><span>About Us</span></li>
            </ul>
        </div>
        <div class="col col-sm"></div>
        <div class="col col-sm-3 right">
            <ul class="navbar">
                <li><span class="fa fa-user">Login</span></li>
                <li><span class="fa fa-phone">Contact us</span></li>
            </ul>
        </div>
    </div>
</div>
