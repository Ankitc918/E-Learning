<div class="wrap100">
   <div class="row wrap80">
       <div class="col left">
           <span>&copy;copyright 2019. All rights reserved.</span>
       </div>
       
       <div class="col right">
           <span>
               Thanks for coming. Visit again.
           </span>
       </div>
   </div>
</div>