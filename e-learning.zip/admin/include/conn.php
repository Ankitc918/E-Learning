<?php 
$conn=mysqli_connect("localhost","root","","E-Learning") or die("error connecting!");

?>
